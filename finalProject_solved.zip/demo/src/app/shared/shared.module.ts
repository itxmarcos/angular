import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MenuComponent } from './menu/menu.component';
import { AlertComponent } from './alert/alert.component';
import { AlertModule } from 'ngx-bootstrap/alert';

@NgModule({
  declarations: [MenuComponent, AlertComponent],
  imports: [CommonModule, AlertModule],
  exports: [MenuComponent, AlertComponent],
})
export class SharedModule {}
