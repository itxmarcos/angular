import { AlertMessage } from './alert-message';

describe('AlertMessage', () => {
  it('should create an instance', () => {
    expect(new AlertMessage()).toBeTruthy();
  });
});
