import { CovidBasicData } from './covid-basic-data';

describe('CovidBasicData', () => {
  it('should create an instance', () => {
    expect(new CovidBasicData()).toBeTruthy();
  });
});
