export class AlertMessage {
  constructor(private message: string, private type: string) {}

  public getMessage(): string {
    return this.message;
  }

  public getType(): string {
    return this.type;
  }
}
