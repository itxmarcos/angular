import { CovidCountryData } from './covid-country-data';

describe('CovidCountryData', () => {
  it('should create an instance', () => {
    expect(new CovidCountryData()).toBeTruthy();
  });
});
