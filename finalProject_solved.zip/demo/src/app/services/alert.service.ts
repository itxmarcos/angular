import { Injectable } from '@angular/core';
import { AlertMessage } from '../models/alert-message';
import { Subject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AlertService {
  private alertSubject: Subject<AlertMessage> = new Subject<AlertMessage>();

  constructor() {}

  getAlertSubscription(): Observable<AlertMessage> {
    return this.alertSubject.asObservable();
  }

  successMessage(message: string) {
    let alertMessage: AlertMessage = new AlertMessage(message, 'success');
    this.alertSubject.next(alertMessage);
  }

  errorMessage(message: string) {
    let alertMessage: AlertMessage = new AlertMessage(message, 'danger');
    this.alertSubject.next(alertMessage);
  }

  infoMessage(message: string) {
    let alertMessage: AlertMessage = new AlertMessage(message, 'info');
    this.alertSubject.next(alertMessage);
  }
}
