import { ValidatorsCv } from './validators-cv';

describe('ValidatorsCv', () => {
  it('should create an instance', () => {
    expect(new ValidatorsCv()).toBeTruthy();
  });
});
