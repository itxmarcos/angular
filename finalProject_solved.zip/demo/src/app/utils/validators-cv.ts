import { AbstractControl } from '@angular/forms';

export class ValidatorsCv {
  static passwordValidator(control: AbstractControl): { [s: string]: boolean } {
    if (!control.value.match(/^(?=.*?\d)(?=.*?[a-zA-Z])[a-zA-Z\d]+$/)) {
      return { invalidPassword: true };
    }
  }
}
