import { Component, OnInit, OnDestroy, AfterContentInit, ElementRef } from '@angular/core';
import { CovidService } from 'src/app/services/covid.service';
import { DatePipe } from '@angular/common';
import { CovidCountryData } from 'src/app/models/covid-country-data';

import { ViewChild } from '@angular/core';

import { DonutChartComponent } from './../donut-chart/donut-chart.component';

export class CaseState {
  state: string;
  stateDisplayValue: string;
  count: number;
}

@Component({
  selector: 'app-live-chart',
  templateUrl: './live-chart.component.html',
  styleUrls: ['./live-chart.component.css']
})
export class LiveChartComponent implements OnInit, OnDestroy, AfterContentInit {

  dates: Date[] = [];

  currentDate: string;

  @ViewChild('ordersByStatusChart', { static: true }) chart: DonutChartComponent;

  caseStates: CaseState[];

  chartData: number[] = [];

  displayedColumns = ['legend', 'caseStatus', 'total'];

  refreshInterval;

  index: number = 0;

  constructor(private covidService: CovidService,
              private datePipe: DatePipe) {
  }

  ngOnInit() {

    this.buildDates();
  }

  initialize() {

    this.currentDate = this.datePipe.transform(this.dates[this.index], 'yyyy-MM-dd');

    this.index = (this.index + 1) % (this.dates.length);

    this.covidService.getCountryData('es', this.currentDate)
      .subscribe((countryData: CovidCountryData) => {
        console.log(countryData);

        this.caseStates = [];
        this.chartData = [];

        const targetStateActive = new CaseState();

        targetStateActive.state = "active";
        targetStateActive.stateDisplayValue = "Active";
        targetStateActive.count = countryData.active;

        this.caseStates.push(targetStateActive);
        this.chartData.push(targetStateActive.count);

        const targetStateConfirmed = new CaseState();

        targetStateConfirmed.state = "confirmed";
        targetStateConfirmed.stateDisplayValue = "Confirmed";
        targetStateConfirmed.count = countryData.confirmed;

        this.caseStates.push(targetStateConfirmed);
        this.chartData.push(targetStateConfirmed.count);

        const targetStateRecovered = new CaseState();

        targetStateRecovered.state = "recovered";
        targetStateRecovered.stateDisplayValue = "Recovered";
        targetStateRecovered.count = countryData.recovered;

        this.caseStates.push(targetStateRecovered);
        this.chartData.push(targetStateRecovered.count);

        const targetStateDeaths = new CaseState();

        targetStateDeaths.state = "deaths";
        targetStateDeaths.stateDisplayValue = "Deaths";
        targetStateDeaths.count = countryData.deaths;

        this.caseStates.push(targetStateDeaths);
        this.chartData.push(targetStateDeaths.count);

        this.chart.data = [...this.chartData];
        
        this.refreshInterval = setInterval(() => {

          this.currentDate = this.datePipe.transform(this.dates[this.index], 'yyyy-MM-dd');

          this.index = (this.index + 1) % (this.dates.length);

          if (document.hasFocus()) {

            this.covidService.getCountryData('es', this.currentDate)
              .subscribe((countryData: CovidCountryData) => {

                this.chartData = [];

                this.caseStates[0].count = countryData.active;
                this.chartData.push(countryData.active);

                this.caseStates[1].count = countryData.confirmed;
                this.chartData.push(countryData.confirmed);

                this.caseStates[2].count = countryData.recovered;
                this.chartData.push(countryData.recovered);

                this.caseStates[3].count = countryData.deaths;
                this.chartData.push(countryData.deaths);

                this.chart.data = [...this.chartData];
              });
          }
        }, 1000);
      });
  }

  ngOnDestroy() {
    if (this.refreshInterval) {
      clearInterval(this.refreshInterval);
    }
  }

  ngAfterContentInit() {
    this.initialize();
  }

  private buildDates() {

    const firstDate: Date = new Date("2020-02-25Z08:00:00");
    const lastDate: Date = new Date("2020-06-05Z08:00:00");

    while( firstDate <= lastDate ) {

      firstDate.setDate(firstDate.getDate() + 1);

      this.dates.push(new Date(firstDate));
    }
  }
}
