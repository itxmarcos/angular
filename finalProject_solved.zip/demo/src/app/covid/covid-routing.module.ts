import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { WorldListComponent } from './world-list/world-list.component';
import { WorldMapComponent } from './world-map/world-map.component';
import { CountryResolverService } from '../resolvers/country-resolver.service';
import { AuthGuard } from '../guards/auth.guard';
import { DonutChartComponent } from './donut-chart/donut-chart.component';
import { LiveChartComponent } from './live-chart/live-chart.component';

const routes: Routes = [
  {
    path: 'dashboard',
    component: DashboardComponent,
    canActivate: [AuthGuard],
  },
  {
    path: 'world-list',
    component: WorldListComponent,
    resolve: {
      countriesResolved: CountryResolverService,
    },
    canActivate: [AuthGuard],
  },
  {
    path: 'world-map',
    component: WorldMapComponent,
    resolve: {
      countriesResolved: CountryResolverService,
    },
    canActivate: [AuthGuard],
  },
  {
    path: 'live',
    component: LiveChartComponent,
    canActivate: [AuthGuard],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CovidRoutingModule {}
