import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CovidRoutingModule } from './covid-routing.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { WorldMapComponent } from './world-map/world-map.component';
import { WorldListComponent } from './world-list/world-list.component';
import { LeafletModule } from '@asymmetrik/ngx-leaflet';
import { DonutChartComponent } from './donut-chart/donut-chart.component';
import { LiveChartComponent } from './live-chart/live-chart.component';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { FormsModule } from '@angular/forms';
import { MatMenuModule } from '@angular/material/menu';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';

@NgModule({
  declarations: [
    DashboardComponent,
    WorldMapComponent,
    WorldListComponent,
    DonutChartComponent,
    LiveChartComponent,
  ],
  imports: [
    CommonModule,
    CovidRoutingModule,
    LeafletModule,
    PaginationModule.forRoot(),
    FormsModule,
    MatMenuModule,
    MatIconModule,
    MatCardModule,
    MatSelectModule,
    MatTableModule,
    MatButtonModule,
    MatSlideToggleModule,
  ],
})
export class CovidModule {}
