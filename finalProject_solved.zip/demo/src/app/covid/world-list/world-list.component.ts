import { Component, OnInit } from '@angular/core';
import { CovidCountryData } from 'src/app/models/covid-country-data';
import { ActivatedRoute } from '@angular/router';
import { CovidService } from 'src/app/services/covid.service';

@Component({
  selector: 'app-world-list',
  templateUrl: './world-list.component.html',
  styleUrls: ['./world-list.component.css']
})
export class WorldListComponent implements OnInit {

  countryDataList: CovidCountryData[];

  pageResults: CovidCountryData[];

  currentPage : number;

  pageChanged(event: any): void {
    this.currentPage = event.page;

    this.covidService.setPageNumber(this.currentPage);

    this.pageResults = this.countryDataList.slice((this.currentPage - 1) * 10, this.currentPage * 10);
  }

  constructor(private covidService: CovidService,
    private activatedRoute: ActivatedRoute) {
    
    //console.log(activatedRoute);
    this.countryDataList = this.activatedRoute.snapshot.data['countriesResolved'];
  }

  ngOnInit(): void {

    if (!this.currentPage)
    {
      this.currentPage = this.covidService.getPageNumber();
    }

    this.pageResults = this.countryDataList.slice((this.currentPage - 1) * 10, this.currentPage * 10);
  }

}
